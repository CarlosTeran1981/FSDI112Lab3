from django.db import models

# Create your models here.

"""
field:
  Char (string)
  Int
  Float
  Boolean
"""
class Genre(models.Model):
    name = models.CharField(max_length=250)

    def __str__(self):
        return str(self.id) + " | " + self.name

class Movie(models.Model):
    title = models.CharField(max_length=250)
    release_year = models.IntegerField()
    in_stock = models.IntegerField()
    price = models.FloatField()
    duration_min = models.IntegerField()
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id) + " | " + str(self.release_year) + " | " + self.title

class Serie(models.Model):
    title = models.CharField(max_length=250)
    release_year = models.IntegerField()
    seasons = models.IntegerField()
    in_stock = models.IntegerField()
    price = models.FloatField()
    duration_min = models.IntegerField()
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id) + " | " + str(self.release_year) + " | " + str(self.seasons) + " | " + self.title



"""

python manage.py makemigrations

python manage.py migrate


"""

